import SamplePage from 'views/sample-page';

// ==============================|| PAGE ||============================== //

export default function SampleViewPage() {
  return <SamplePage />;
}
