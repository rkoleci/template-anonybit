import InvoiceDashboardApp from 'views/apps/invoice/dashboard';

// ==============================|| PAGE ||============================== //

export default function InvoiceDashboardPage() {
  return <InvoiceDashboardApp />;
}
