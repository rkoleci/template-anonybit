import DashboardAnalytics from 'views/dashboard/analytics';

export default function AnalyticsPage() {
  return <DashboardAnalytics />;
}
