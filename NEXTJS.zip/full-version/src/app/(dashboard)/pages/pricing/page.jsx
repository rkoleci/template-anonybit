import Pricing from 'views/pricing';

// ==============================|| PAGE ||============================== //

export default function PricingPage() {
  return <Pricing />;
}
