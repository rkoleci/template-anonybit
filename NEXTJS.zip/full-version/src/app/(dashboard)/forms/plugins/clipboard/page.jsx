import ClipBoardPlugin from 'views/forms/plugins/clipboard';

// ================= PAGE ======================= //

export default function ClipBoardPluginPage() {
  return <ClipBoardPlugin />;
}
