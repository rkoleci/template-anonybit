import MaskPlugins from 'views/forms/plugins/mask';

// ================= PAGE ======================= //

export default function MaskPluginsPage() {
  return <MaskPlugins />;
}
