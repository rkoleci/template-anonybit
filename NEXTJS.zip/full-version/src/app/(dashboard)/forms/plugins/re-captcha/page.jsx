import ReCaptchaPlugin from 'views/forms/plugins/re-captcha';

// ================= PAGE ======================= //

export default function ReCaptchaPluginPage() {
  return <ReCaptchaPlugin />;
}
