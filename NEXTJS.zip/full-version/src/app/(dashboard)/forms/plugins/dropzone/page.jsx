import DropZonePlugin from 'views/forms/plugins/dropzone';

// ================= PAGE ======================= //

export default function DropZonePluginPage() {
  return <DropZonePlugin />;
}
