import FormsWizard from 'views/forms/wizard';

// ==============================|| PAGE ||============================== //

export default function FormsWizardPage() {
  return <FormsWizard />;
}
