import ActionBarLayout from 'views/forms/layouts/action-bar';

// ==============================|| PAGE ||============================== //

export default function ActionBarLayoutPage() {
  return <ActionBarLayout />;
}
