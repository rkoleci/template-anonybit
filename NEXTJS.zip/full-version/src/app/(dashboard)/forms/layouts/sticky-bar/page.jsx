import StickyBarLayout from 'views/forms/layouts/sticky-bar';

// ====================== PAGE =============================//

export default function StickyBarLayoutPage() {
  return <StickyBarLayout />;
}
