import BasicFormsLayout from 'views/forms/layouts/basic';

// ==============================|| PAGE ||============================== //

export default function BasicFormsLayoutPage() {
  return <BasicFormsLayout />;
}
