import WidgetStatistics from 'views/widget/statistics';

export default function WidgetStatisticsPage() {
  return <WidgetStatistics />;
}
