import FilterTable from 'views/tables/react-table/filtering';

// ==============================|| PAGE ||============================== //

export default function FilterTablePage() {
  return <FilterTable />;
}
