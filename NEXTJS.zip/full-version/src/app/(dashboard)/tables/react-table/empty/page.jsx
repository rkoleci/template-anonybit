import EmptyTable from 'views/tables/react-table/empty';

// ==============================|| PAGE ||============================== //

export default function EmptyTablePage() {
  return <EmptyTable />;
}
