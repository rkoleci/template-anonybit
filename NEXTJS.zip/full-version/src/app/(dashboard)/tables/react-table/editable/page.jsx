import EditableTable from 'views/tables/react-table/editable';

// ==============================|| PAGE ||============================== //

export default function EditableTablePage() {
  return <EditableTable />;
}
