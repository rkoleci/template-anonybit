import StickyTable from 'views/tables/react-table/sticky-table';

// ==============================|| PAGE ||============================== //

export default function StickyTablePage() {
  return <StickyTable />;
}
