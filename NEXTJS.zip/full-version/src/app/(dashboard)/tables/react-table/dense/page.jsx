import DenseTable from 'views/tables/react-table/dense';

// ==============================|| PAGE ||============================== //

export default function DenseTablePage() {
  return <DenseTable />;
}
