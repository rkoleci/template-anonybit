import RowSelectTable from 'views/tables/react-table/row-selection';

// ==============================|| PAGE ||============================== //

export default function RowSelectTablePage() {
  return <RowSelectTable />;
}
