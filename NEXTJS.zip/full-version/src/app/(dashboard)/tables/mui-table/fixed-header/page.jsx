import FixedHeader from 'views/tables/mui-table/fixed-header';

// ==============================|| PAGE ||============================== //

export default function FixedHeaderPage() {
  return <FixedHeader />;
}
