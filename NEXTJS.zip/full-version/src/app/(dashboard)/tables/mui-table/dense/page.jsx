import DenseTable from 'views/tables/mui-table/dense';

// ==============================|| PAGE ||============================== //

export default function DenseTablePage() {
  return <DenseTable />;
}
