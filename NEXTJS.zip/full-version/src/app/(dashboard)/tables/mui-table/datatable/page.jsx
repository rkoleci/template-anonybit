import DataTable from 'views/tables/mui-table/datatable';

// ==============================|| PAGE ||============================== //

export default function DataTablePage() {
  return <DataTable />;
}
