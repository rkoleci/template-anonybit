import BasicTable from 'views/tables/mui-table/basic';

// ==============================|| PAGE ||============================== //

export default function BasicTablePage() {
  return <BasicTable />;
}
