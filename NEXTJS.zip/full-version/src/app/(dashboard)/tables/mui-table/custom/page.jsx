import CustomTable from 'views/tables/mui-table/custom';

// ==============================|| PAGE ||============================== //

export default function CustomTablePage() {
  return <CustomTable />;
}
