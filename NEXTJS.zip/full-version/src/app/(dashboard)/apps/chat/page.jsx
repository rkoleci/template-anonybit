import ChatApp from 'views/apps/chat';

// ==============================|| PAGE ||============================== //

export default function ChatAppPage() {
  return <ChatApp />;
}
