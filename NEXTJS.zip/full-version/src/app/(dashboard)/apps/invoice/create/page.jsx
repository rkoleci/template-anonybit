import CreateInvoiceApp from 'views/apps/invoice/create';

// ==============================|| PAGE ||============================== //

export default function CreateInvoiceAppPage() {
  return <CreateInvoiceApp />;
}
