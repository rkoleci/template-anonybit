import CheckoutApp from 'views/apps/e-commerce/checkout';

// ==============================|| PAGE ||============================== //

export default function CheckoutAppPage() {
  return <CheckoutApp />;
}
