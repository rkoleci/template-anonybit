import ProdListApp from 'views/apps/e-commerce/products-list';

// ==============================|| PAGE ||============================== //

export default function ProdListAppPage() {
  return <ProdListApp />;
}
