import AddProduct from 'views/apps/e-commerce/add-product';

// ==============================|| PAGE ||============================== //

export default function AddProductPage() {
  return <AddProduct />;
}
