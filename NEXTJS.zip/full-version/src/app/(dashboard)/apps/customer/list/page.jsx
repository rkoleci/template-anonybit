import CustmListApp from 'views/apps/customer/list';

// ==============================|| PAGE ||============================== //

export default function CustmListAppPage() {
  return <CustmListApp />;
}
