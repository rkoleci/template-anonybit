import CustmCardApp from 'views/apps/customer/card';

// ==============================|| PAGE ||============================== //

export default function CustmCardAppPage() {
  return <CustmCardApp />;
}
