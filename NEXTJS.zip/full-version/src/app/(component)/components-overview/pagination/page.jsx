import ComponentPagination from 'views/components-overview/pagination';

export default function PaginationPage() {
  return <ComponentPagination />;
}
