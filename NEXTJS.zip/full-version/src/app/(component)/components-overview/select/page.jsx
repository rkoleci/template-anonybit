import ComponentSelect from 'views/components-overview/select';

export default function SelectPage() {
  return <ComponentSelect />;
}
