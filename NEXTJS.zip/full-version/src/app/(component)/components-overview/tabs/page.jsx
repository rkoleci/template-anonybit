import ComponentTabs from 'views/components-overview/tabs';

export default function TabsPage() {
  return <ComponentTabs />;
}
