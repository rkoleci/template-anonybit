import ComponentTypography from 'views/components-overview/typography';

export default function TypographyPage() {
  return <ComponentTypography />;
}
