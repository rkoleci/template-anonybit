import ComponentSlider from 'views/components-overview/slider';

export default function SliderPage() {
  return <ComponentSlider />;
}
