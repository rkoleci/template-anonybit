import ComponentStepper from 'views/components-overview/stepper';

export default function StepperPage() {
  return <ComponentStepper />;
}
