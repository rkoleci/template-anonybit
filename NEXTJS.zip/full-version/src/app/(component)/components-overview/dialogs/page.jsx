import Dialogs from 'views/components-overview/dialogs';

export default function DialogsPage() {
  return <Dialogs />;
}
