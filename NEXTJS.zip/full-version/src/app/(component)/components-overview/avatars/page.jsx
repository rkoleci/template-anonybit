import ComponentAvatar from 'views/components-overview/avatars';

export default function AvatarPage() {
  return <ComponentAvatar />;
}
