import ComponentDateTimePicker from 'views/components-overview/date-time-picker';

export default function DateTimePickerPage() {
  return <ComponentDateTimePicker />;
}
