'use client';

// project imports
import Error500 from 'views/maintenance/500';

// ==============================|| ERROR - MAIN ||============================== //

export default function Error() {
  return <Error500 />;
}
