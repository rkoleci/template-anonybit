import UnderConstruction from 'views/maintenance/under-construction';

// ==============================|| PAGE ||============================== //

export default function UnderConstructionPage() {
  return <UnderConstruction />;
}
