import ResetPassword from 'views/auth/reset-password';

// ==============================|| PAGE ||============================== //

export default function ResetPasswordPage() {
  return <ResetPassword />;
}
