import ForgotPassword from 'views/auth/forgot-password';

// ==============================|| PAGE ||============================== //

export default function ForgotPasswordPage() {
  return <ForgotPassword />;
}
