import SignIn from 'views/auth/login';

// ==============================|| PAGE ||============================== //

export default function SignInPage() {
  return <SignIn />;
}
