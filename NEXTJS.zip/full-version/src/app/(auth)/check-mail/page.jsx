import CheckMail from 'views/auth/check-mail';

// ==============================|| PAGE ||============================== //

export default function CheckMailPage() {
  return <CheckMail />;
}
