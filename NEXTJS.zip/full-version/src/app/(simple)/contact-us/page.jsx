import ContactUS from 'views/contact-us';

// ==============================|| PAGE ||============================== //

export default function ContactUSPage() {
  return <ContactUS />;
}
