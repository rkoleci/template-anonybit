'use client';

export { NumericFormat } from 'react-number-format';
