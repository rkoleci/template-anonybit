import { Outlet } from 'react-router-dom';

// ==============================|| LAYOUT - BLANK PAGES ||============================== //

export default function PagesLayout() {
  return <Outlet />;
}
